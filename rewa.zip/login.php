<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Rewa Bhagirathi Sewa - Login</title>
<?php include("includes/header.php"); ?>

<div class="login-page">
  <div class="left"> <img src="assets/images/login-img.jpg" alt=""> </div>
  <div class="right">
    <form action="" class="login-form">
      <h3>Login your Account</h3>
      <div class="form-group">
        <label for="" class="col-form-label">Enter your Emaiil</label>
        <input type="text" class="form-control bg-secondary border-2 rounded-0 border-primary">
      </div>
      <div class="form-group mt-2">
        <label for="" class="col-form-label">Enter Password</label>
        <input type="password" class="form-control bg-secondary rounded-0 border-2 border-primary">
      </div>
      <div class="d-flex align-items-center justify-content-between my-3" >
        <div class="form-check form-switch">
          <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" checked>
          <label class="form-check-label" for="flexSwitchCheckChecked">Remember me</label>
        </div>
        <a href="forgot-password.php"> Forgot Password? </a> </div>
      <button class="btn btn-primary rounded-0 w-100">Login</button>
      <div class="d-flex align-items-center justify-content-between my-3" > <span>Don’t have an account?</span> <a href="donor-register.php"> Sign up now </a> </div>
    </form>
  </div>
</div>
<?php include("includes/login-footer.php"); ?>
