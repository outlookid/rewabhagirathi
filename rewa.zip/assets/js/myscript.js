const swiper = new Swiper('.swiper', {
  loop: true,
  navigation: {
    nextEl: '.button-next',
    prevEl: '.button-prev',
  }
});

var swiper2 = new Swiper(".mySwiper", {
  slidesPerView: 1,
  spaceBetween: 10,
  loop: true,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
  breakpoints: {
    640: {
      slidesPerView: 2,
      spaceBetween: 20,
    },
    768: {
      slidesPerView: 4,
      spaceBetween: 20,
    },
    1024: {
      slidesPerView: 4,
      spaceBetween: 20,
    },
  },
});

$(document).on('click', 'input.checklink[type="checkbox"]', function () {
  $('input.checklink[type="checkbox"]').not(this).prop('checked', false);
});

Fancybox.bind('[data-fancybox="gallery"]', {

});
$(window).scroll(function () {
  var scroll = $(window).scrollTop();

  //>=, not <=
  if (scroll >= 270) {
    //clearHeader, not clearheader - caps H
    $(".bottom-total").addClass("d-block");
  } else {
    $(".bottom-total").removeClass("d-block");
  }
}); //missing );
