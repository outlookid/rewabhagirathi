<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Rewa Bhagirathi Sewa - Donor Registration</title>
<?php include("includes/header.php"); ?>
<div class="register-page bg-warning">
  <div class="py-5">
    <form action="" class="login-form mt-5 mt-md-0">
      <h3 class="text-center mb-3 fs-4 text-uppercase">Donor Registration</h3>
      <div class="container">
        <div class="card border-2 border-primary">
          <div class="card-body px-md-4">
            <div class="row gy-2">
              <div class="col-lg-3">
                <div class="form-group">
                  <label for="" class="col-form-label">Name</label>
                  <div class="input-group">
                    <select name="" id="" class="form-select mw-75px bg-secondary border-primary border-end-0">
                      <option value="">Mr.</option>
                      <option value="">Miss.</option>
                    </select>
                    <input type="text" class="form-control bg-secondary border-primary">
                  </div>
                </div>
              </div>
              <div class="col-lg-3">
                <div class="form-group">
                  <label for="" class="col-form-label">Date of Birth</label>
                  <input type="text" class="form-control bg-secondary border-primary">
                </div>
              </div>
              <div class="col-lg-3">
                <div class="form-group">
                  <label for="" class="col-form-label">Mobile Number</label>
                  <div class="input-group">
                    <select name="" id="" class="form-select mw-75px bg-secondary border-primary border-end-0">
                      <option value="">+91</option>
                      <option value="">+1</option>
                    </select>
                    <input type="text" class="form-control bg-secondary border-primary">
                  </div>
                </div>
              </div>
              <div class="col-lg-3">
                <div class="form-group">
                  <label for="" class="col-form-label">Whatsapp Number</label>
                  <div class="input-group">
                    <select name="" id="" class="form-select mw-75px bg-secondary border-primary border-end-0">
                      <option value="">+91</option>
                      <option value="">+1</option>
                    </select>
                    <input type="text" class="form-control bg-secondary border-primary">
                  </div>
                </div>
              </div>
              <div class="col-lg-3">
                <div class="form-group">
                  <label for="" class="col-form-label">Email</label>
                  <input type="text" class="form-control bg-secondary border-primary">
                </div>
              </div>
              <div class="flex-wrap"></div>
              <div class="col-lg-3">
                <div class="form-group">
                  <label for="" class="col-form-label">Country</label>
                  <select name="" id="" class="form-select bg-secondary border-primary">
                    <option value="">Select Country</option>
                  </select>
                </div>
              </div>
              <div class="col-lg-3">
                <div class="form-group">
                  <label for="" class="col-form-label">State</label>
                  <select name="" id="" class="form-select bg-secondary border-primary">
                    <option value="">Select State</option>
                  </select>
                </div>
              </div>
              <div class="col-lg-3">
                <div class="form-group">
                  <label for="" class="col-form-label">City</label>
                  <select name="" id="" class="form-select bg-secondary border-primary">
                    <option value="">Select City</option>
                  </select>
                </div>
              </div>
              <div class="col-lg-3">
                <div class="form-group">
                  <label for="" class="col-form-label">District</label>
                  <select name="" id="" class="form-select bg-secondary border-primary">
                    <option value="">Select District</option>
                  </select>
                </div>
              </div>
              <div class="col-lg-3">
                <div class="form-group">
                  <label for="" class="col-form-label">Pincode</label>
                  <input type="text" class="form-control bg-secondary border-primary">
                </div>
              </div>
              <div class="col-lg-6">
                <div class="form-group">
                  <label for="" class="col-form-label">Address</label>
                  <input type="text" class="form-control bg-secondary border-primary">
                </div>
              </div>
              <div class="col-lg-3">
                <div class="form-group">
                  <label for="" class="col-form-label">Source</label>
                  <select name="" id="" class="form-select bg-secondary border-primary">
                    <option value="">Select Source</option>
                  </select>
                </div>
              </div>
              <div class="col-lg-12 text-center mt-4">
                <button class="btn btn-primary rounded-0 px-5">Login</button>
                <button class="btn btn-outline-primary  rounded-0 px-5">Reset</button>
              </div>
              <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-center" > <span class="me-1">Already Registered?</span> <a href="login.php"> Login here </a> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
     
     
      
    </form>
  </div>
</div>
<?php include("includes/login-footer.php"); ?>
