<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Rewa Bhagirathi Sewa</title>
<?php include("includes/header.php"); ?>



<section class="py-5 my-5">
  <div class="container">
    <div class="row gy-4">
      <div class="col-lg-12 text-center">
        <h2 class="fw-bold">Gallery</h2>
      </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
    </div>
  </div>
</section>

<a href="#allitems" class="bottom-total"> Click here for Add Items </a>
<?php include("includes/footer.php"); ?>