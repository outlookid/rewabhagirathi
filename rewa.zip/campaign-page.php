<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Rewa Bhagirathi Sewa</title>
<?php include("includes/header.php"); ?>
<div class="modal fade" id="shoeitems" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5">Fodder</h1>
        <h2 class="fs-5 mb-0">SubTotal: 500/-</h2>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-lg-4">
            <div class="card updates-card "> <img src="assets/images/feed-gaugrass-poster.jpg" class="card-img-top" alt="">
              <div class="card-body">
                <div class="d-flex mb-3 align-items-center justify-content-between">
                  <h3 class="fs-5 fw-bold mb-0">Green Fodder</h3>
                  <span class="fw-bold fs-5">₹500/-</span> </div>
                <ul class="modal-list">
                  <li><span>Description</span> :Green crops like legume crops, cereal crops, grass crops</li>
                  <li><span>Benefits</span> : Main preferred food for cows. It is very highly palatable and digestible.</li>
                  <li><span>Requirement</span> : More than 2 million Kg per month</li>
                </ul>
                <div class="text-center">
                  <button data-bs-toggle="modal" data-bs-target="#shoeitems" class="btn btn-primary rounded-0">Add</button>
                </div>
              </div>
            </div>
          </div>
			<div class="col-lg-4">
            <div class="card updates-card "> <img src="assets/images/feed-gaugrass-poster.jpg" class="card-img-top" alt="">
              <div class="card-body">
                <div class="d-flex mb-3 align-items-center justify-content-between">
                  <h3 class="fs-5 fw-bold mb-0">Green Fodder</h3>
                  <span class="fw-bold fs-5">₹500/-</span> </div>
                <ul class="modal-list">
                  <li><span>Description</span> :Green crops like legume crops, cereal crops, grass crops</li>
                  <li><span>Benefits</span> : Main preferred food for cows. It is very highly palatable and digestible.</li>
                  <li><span>Requirement</span> : More than 2 million Kg per month</li>
                </ul>
                <div class="text-center">
                  <button data-bs-toggle="modal" data-bs-target="#shoeitems" class="btn btn-primary rounded-0">Add</button>
                </div>
              </div>
            </div>
          </div>
			<div class="col-lg-4">
            <div class="card updates-card "> <img src="assets/images/feed-gaugrass-poster.jpg" class="card-img-top" alt="">
              <div class="card-body">
                <div class="d-flex mb-3 align-items-center justify-content-between">
                  <h3 class="fs-5 fw-bold mb-0">Green Fodder</h3>
                  <span class="fw-bold fs-5">₹500/-</span> </div>
                <ul class="modal-list">
                  <li><span>Description</span> :Green crops like legume crops, cereal crops, grass crops</li>
                  <li><span>Benefits</span> : Main preferred food for cows. It is very highly palatable and digestible.</li>
                  <li><span>Requirement</span> : More than 2 million Kg per month</li>
                </ul>
                <div class="text-center">
                  <button data-bs-toggle="modal" data-bs-target="#shoeitems" class="btn btn-primary rounded-0">Add</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer justify-content-center">
        
        <button type="button" class="btn btn-primary rounded-0 px-4" data-bs-dismiss="modal">Okay</button>
      </div>
    </div>
  </div>
</div>
<div class="container ">
  <div class="row">
    <div class="col-lg-12">
      <div class="d-flex gap-3 align-items-center justify-content-end"> <i class="small">Share to Save Precious<br>
        Life of Mother Cows</i>
        <ul class="sharenow">
          <li><a href=""><img src="assets/images/facebook.svg" alt=""></a></li>
          <li><a href=""><img src="assets/images/twitter.svg" alt=""></a></li>
          <li><a href=""><img src="assets/images/linkedin.svg" alt=""></a></li>
          <li><a href=""><img src="assets/images/whatsapp.svg" alt=""></a></li>
        </ul>
      </div>
    </div>
    <div class="col-lg-12">
      <div class="card bg-secondary border-2 border-primary border-dashed">
        <div class="card-header bg-primary text-center ">
          <div class="card-title text-white mb-0">Tax Exempted under section 80G of Income tax vide Approval No AAGAS2376CE20206</div>
        </div>
        <div class="card-body">
          <div class="row align-items-center">
            <div class="col-lg-6">
              <div class="row gy-2">
                <div class="col-lg-6">
                  <p class="mb-0">Total Food Required</p>
                  <h3 class="fs-5 fw-bold">31 Lakh Kg</h3>
                </div>
                <div class="col-lg-6">
                  <p class="mb-0">Month</p>
                  <h3 class="fs-5 fw-bold">February 2023</h3>
                </div>
                <div class="col-lg-12">
                  <div class="progress bg-white" role="progressbar" aria-label="Example with label" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                    <div class="progress-bar" style="width: 25%">25%</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6 text-end">
              <button class="btn btn-primary rounded-0 px-4">Add Product to Donate</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="container mt-4 pb-5" id="allitems">
  <div class="row gy-4">
    <div class="col-xl-4">
      <div class="card updates-card "> <img src="assets/images/feed-gaugrass-poster.jpg" class="card-img-top" alt="">
        <div class="card-body text-center">
          <h3 class="fs-5 fw-bold">Fodder</h3>
          <p>Mix of different types of fodder are being fed to Gauvansh. You can select the fodder type which you want to Feed.</p>
          <button data-bs-toggle="modal" data-bs-target="#shoeitems" class="btn btn-primary rounded-0">Add Items</button>
        </div>
      </div>
    </div>
    <div class="col-xl-4">
      <div class="card updates-card"> <img src="assets/images/feed-gaugrass-poster.jpg" class="card-img-top" alt="">
        <div class="card-body text-center">
          <h3 class="fs-5 fw-bold">Fodder</h3>
          <p>Mix of different types of fodder are being fed to Gauvansh. You can select the fodder type which you want to Feed.</p>
          <button data-bs-toggle="modal" data-bs-target="#shoeitems" class="btn btn-primary rounded-0">Add Items</button>
        </div>
      </div>
    </div>
    <div class="col-xl-4">
      <div class="card updates-card"> <img src="assets/images/feed-gaugrass-poster.jpg" class="card-img-top" alt="">
        <div class="card-body text-center">
          <h3 class="fs-5 fw-bold">Fodder</h3>
          <p>Mix of different types of fodder are being fed to Gauvansh. You can select the fodder type which you want to Feed.</p>
          <button data-bs-toggle="modal" data-bs-target="#shoeitems" class="btn btn-primary rounded-0">Add Items</button>
        </div>
      </div>
    </div>
    <div class="col-xl-4">
      <div class="card updates-card"> <img src="assets/images/feed-gaugrass-poster.jpg" class="card-img-top" alt="">
        <div class="card-body text-center">
          <h3 class="fs-5 fw-bold">Fodder</h3>
          <p>Mix of different types of fodder are being fed to Gauvansh. You can select the fodder type which you want to Feed.</p>
          <button data-bs-toggle="modal" data-bs-target="#shoeitems" class="btn btn-primary rounded-0">Add Items</button>
        </div>
      </div>
    </div>
    <div class="col-xl-4">
      <div class="card updates-card"> <img src="assets/images/feed-gaugrass-poster.jpg" class="card-img-top" alt="">
        <div class="card-body text-center">
          <h3 class="fs-5 fw-bold">Fodder</h3>
          <p>Mix of different types of fodder are being fed to Gauvansh. You can select the fodder type which you want to Feed.</p>
          <button data-bs-toggle="modal" data-bs-target="#shoeitems" class="btn btn-primary rounded-0">Add Items</button>
        </div>
      </div>
    </div>
    <div class="col-xl-4">
      <div class="card updates-card"> <img src="assets/images/feed-gaugrass-poster.jpg" class="card-img-top" alt="">
        <div class="card-body text-center">
          <h3 class="fs-5 fw-bold">Fodder</h3>
          <p>Mix of different types of fodder are being fed to Gauvansh. You can select the fodder type which you want to Feed.</p>
          <button data-bs-toggle="modal" data-bs-target="#shoeitems" class="btn btn-primary rounded-0">Add Items</button>
        </div>
      </div>
    </div>
  </div>
</div>
<section class="container mt-4">
  <div class="row gy-5">
    <div class="col-lg-12 text-center">
      <h2 class="fw-bold mb-4">Cause</h2>
      <p>Once a cow grows old and stop giving milk, their owner disowns them because they are of no use to them. Thousands of such innocent cows are left on the street without a home. Many of these are just aged, injured, or abandoned. Some of these cows fall prey in the hands of butchers. Others are deeply starved and move from one place to another in search of food bearing the brunt of weather. These cows are insulted, canned and even pelted with stones. Some of these even meet with fatal accidents, others groan in pain due to severe injuries waiting for medical attention. The life of these cows become miserable.</p>
    </div>
    <div class="col-lg-6"> <img src="assets/images/video.jpg" class="img-fluid" alt=""> </div>
    <div class="col-lg-6">
      <h3 class="fs-1 fw-bold">According to the Livestock
        Census, 2019, India is home
        to more than 19.34 million
        stray cattle.</h3>
      <p>It aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat</p>
      <a class="btn btn-primary rounded-0"> Donate Now </a> </div>
    <div class="col-lg-12 text-center">
      <h2 class="fw-bold mb-4">What we do</h2>
      <p>Once a cow grows old and stop giving milk, their owner disowns them because they are of no use to them. Thousands of such innocent cows are left on the street without a home. Many of these are just aged, injured, or abandoned. Some of these cows fall prey in the hands of butchers. Others are deeply starved and move from one place to another in search of food bearing the brunt of weather. These cows are insulted, canned and even pelted with stones. Some of these even meet with fatal accidents, others groan in pain due to severe injuries waiting for medical attention. The life of these cows become miserable.</p>
    </div>
  </div>
</section>
<section class="bg-secondary py-5 my-5">
  <div class="container">
    <div class="row gy-4">
      <div class="col-lg-12 text-center">
        <h2 class="fw-bold">Gallery</h2>
      </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
      <div class="col-lg-3"> <a href="assets/images/g1.jpg" data-fancybox="gallery" data-caption=""> <img src="assets/images/g1.jpg" class="img-fluid" /> </a> </div>
    </div>
  </div>
</section>
<section class="container">
  <div class="row gy-5">
    <div class="col-lg-12 text-center">
      <h2 class="fw-bold mb-4">About us</h2>
      <p>‘Shree Krishnayan Desi Gauraksha Evam Gaulok Dham Sewa Samiti’ is one of the largest Gaurakshashala of desi cows in India. We protect, feed & shelter ailing, starving, destitute and stray desi cows majority of which are abandoned by their owners or saved from butchers. Most of these Gauvansh are milk barren. This gaushala is run and managed by saints. We do not sell milk or milk products. We started with just 11 cows in the year 2010 in Haridwar and presently we shelter and feed more than 18000 cows We are registered with Animal Welfare Board of India (Chennai) and with animal welfare board in various states.</p>
    </div>
    <div class="col-lg-12">
      <div class="d-flex  align-items-center flex-column justify-content-center">
        <h2 class="fw-bold">Testimonials</h2>
      </div>
    </div>
    <div class="col-xl-12">
      <div class="swiper mySwiper">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <div class="card test-card bg-secondary border-2 border-primary">
              <div class="card-body text-center"> <img src="assets/images/yogi.png" class="test-image" alt="">
                <h3 class="fs-5 mb-0 text-primary">Shri Yogi Adityanath</h3>
                <small class="text-uppercase">CM, Uttar Pradesh</small> <img src="assets/images/stars.svg" class="starwidth" alt="">
                <p>I was overwhelmed to see the continuous service of thousands of destitute cows in Shri Krishnayan Gaushala. This gaushala can be ideal in the field of Gauseva.</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="card test-card bg-secondary border-2 border-primary">
              <div class="card-body text-center"> <img src="assets/images/yogi.png" class="test-image" alt="">
                <h3 class="fs-5 mb-0 text-primary">Shri Yogi Adityanath</h3>
                <small class="text-uppercase">CM, Uttar Pradesh</small> <img src="assets/images/stars.svg" class="starwidth" alt="">
                <p>I was overwhelmed to see the continuous service of thousands of destitute cows in Shri Krishnayan Gaushala. This gaushala can be ideal in the field of Gauseva.</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="card test-card bg-secondary border-2 border-primary">
              <div class="card-body text-center"> <img src="assets/images/yogi.png" class="test-image" alt="">
                <h3 class="fs-5 mb-0 text-primary">Shri Yogi Adityanath</h3>
                <small class="text-uppercase">CM, Uttar Pradesh</small> <img src="assets/images/stars.svg" class="starwidth" alt="">
                <p>I was overwhelmed to see the continuous service of thousands of destitute cows in Shri Krishnayan Gaushala. This gaushala can be ideal in the field of Gauseva.</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="card test-card bg-secondary border-2 border-primary">
              <div class="card-body text-center"> <img src="assets/images/yogi.png" class="test-image" alt="">
                <h3 class="fs-5 mb-0 text-primary">Shri Yogi Adityanath</h3>
                <small class="text-uppercase">CM, Uttar Pradesh</small> <img src="assets/images/stars.svg" class="starwidth" alt="">
                <p>I was overwhelmed to see the continuous service of thousands of destitute cows in Shri Krishnayan Gaushala. This gaushala can be ideal in the field of Gauseva.</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="card test-card bg-secondary border-2 border-primary">
              <div class="card-body text-center"> <img src="assets/images/yogi.png" class="test-image" alt="">
                <h3 class="fs-5 mb-0 text-primary">Shri Yogi Adityanath</h3>
                <small class="text-uppercase">CM, Uttar Pradesh</small> <img src="assets/images/stars.svg" class="starwidth" alt="">
                <p>I was overwhelmed to see the continuous service of thousands of destitute cows in Shri Krishnayan Gaushala. This gaushala can be ideal in the field of Gauseva.</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <!----> 
          
        </div>
        <div class="swiper-pagination"></div>
      </div>
    </div>
  </div>
</section>
<a href="#allitems" class="bottom-total"> Click here for Add Items </a>
<?php include("includes/footer.php"); ?>