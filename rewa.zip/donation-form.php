<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Rewa Bhagirathi Sewa - Donor Registration</title>
<?php include("includes/header.php"); ?>
<div class="bg-warning mvh-100">
  <div class="donation-form pt-5">
    <div class="container">
      <div class="row gy-4 justify-content-center">
        <div class="col-lg-12">
          <ul class="formtab-links">
            <li class="active">One Time Payment</li>
            <li>Monthly Payment</li>
          </ul>
        </div>
        <div class="col-lg-9">
          <div class="card bg-secondary border-1 border-primary">
            <div class="card-body">
              <div class="row gy-4">
                <div class="col-lg-4">
                  <div class="form-group">
                    <label for="" class="col-form-label fw-semibold pt-0">Please Choose Currency Type</label>
                    <select name="" id="" class="form-select border-primary">
                      <option value="">INR</option>
                    </select>
                  </div>
                </div>
                <div class="col-lg-4">
                  <div class="form-group">
                    <label for="" class="col-form-label fw-semibold pt-0">Enter Amount*</label>
                    <input type="text" class="form-control border-primary" >
                  </div>
                </div>
                <div class="col-lg-4">
                  <div class="form-group">
                    <label for="" class="col-form-label fw-semibold pt-0">Pancard</label>
                    <input type="text" class="form-control border-primary" placeholder="(Mandatory for 80G receipt)">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-9">
          <div class="card bg-secondary border-1 border-primary">
            <div class="card-body">
              <div class="row gy-4">
                <div class="col-lg-4">
                  <div class="form-group">
                    <label for="" class="col-form-label pt-0 fw-semibold">Full Name</label>
                    <div class="input-group">
                      <select name="" id="" class="form-select mw-75px border-primary border-end-0">
                        <option value="">Mr.</option>
                        <option value="">Miss.</option>
                      </select>
                      <input type="text" class="form-control  border-primary">
                    </div>
                  </div>
                </div>
                <div class="col-lg-4">
                  <div class="form-group">
                    <label for="" class="col-form-label pt-0 fw-semibold">Mobile Number</label>
                    <div class="input-group">
                      <select name="" id="" class="form-select mw-75px  border-primary border-end-0">
                        <option value="">+91</option>
                        <option value="">+1</option>
                      </select>
                      <input type="text" class="form-control border-primary">
                    </div>
                  </div>
                </div>
                <div class="col-lg-4">
                  <div class="form-group">
                    <label for="" class="col-form-label fw-semibold pt-0">Email</label>
                    <input type="text" class="form-control border-primary" placeholder="">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-9">
          <div class="card bg-secondary border-1 border-primary">
            <div class="card-body">
              <div class="row gy-4">
                <div class="col-lg-4">
                  <div class="form-group">
                    <label for="" class="col-form-label fw-semibold pt-0">Country</label>
                    <select name="" id="" class="form-select border-primary">
                      <option value="">Select Country</option>
                    </select>
                  </div>
                </div>
                <div class="col-lg-4">
                  <div class="form-group">
                    <label for="" class="col-form-label fw-semibold pt-0">State</label>
                    <select name="" id="" class="form-select  border-primary">
                      <option value="">Select State</option>
                    </select>
                  </div>
                </div>
                <div class="col-lg-4">
                  <div class="form-group">
                    <label for="" class="col-form-label fw-semibold pt-0">City</label>
                    <select name="" id="" class="form-select  border-primary">
                      <option value="">Select City</option>
                    </select>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="form-check">
                    <input class="form-check-input border-primary border-1" type="checkbox" value="" id="c1">
                    <label class="form-check-label" for="c1"> Enter Complete Address for Postal Communication </label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input border-primary border-1" type="checkbox" value="" id="c2">
                    <label class="form-check-label" for="c2"> Enter Event Date & Type </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-9">
          <div class="card bg-secondary border-1 border-primary">
            <div class="card-body">
              <div class="row gy-4">
                <div class="col-lg-12">
                  <h4 class="fs-5 mb-3">Select payment mode (Only Indian bank & Cards)</h4>
                  <div class="form-check">
                    <input class="form-check-input border-primary border-1 checklink" name="selectpay" type="checkbox" value="" id="p1">
                    <label class="form-check-label" for="p1"> Credit Card/ Debit Card/ Net Banking/ UPI/ QR Code/Paytm/GPay/ Phonepe/Amazon pay </label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input border-primary border-1 checklink" name="selectpay" type="checkbox" value="" id="p2">
                    <label class="form-check-label" for="p2">  Download & Pay through QR Code</label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
		<div class="col-lg-9 text-center">
		  	<button class="btn btn-primary rounded-0 mb-5 mt-4 btn-lg">Proceed</button>
		  </div>
      </div>
    </div>
  </div>
</div>
<?php include("includes/footer.php"); ?>
