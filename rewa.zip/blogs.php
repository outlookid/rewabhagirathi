<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Rewa Bhagirathi Sewa</title>
<?php include("includes/header.php"); ?>




<section class="py-5">
  <div class="container">
    <div class="row gy-4">
      <div class="col-lg-12">
        <div class="text-center">
          <h2 class="fw-bold mt-5">Blogs</h2>
          <p>That they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail</p>
        </div>
      </div>
      <div class="col-lg-12 mb-5">
        <div class="row gy-4">
          <div class="col-lg-3">
            <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/b1.jpg" class="card-img-top" alt="...">
              <div class="card-body bg-secondary"> <small class="lh-sm mb-2 d-block"> july, 14 2023 </small>
                <h5 class="card-title text-black">Why Cow is Mother of Hindu?</h5>
                <p class="card-text">In our Hindu culture, cow is not only considered as an animal but also as a lorem
                  <deity class=""></deity>
                </p>
                <a href="blog-details.php" class="mt-4 fw-bold">READ MORE</a> </div>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/b2.jpg" class="card-img-top" alt="...">
              <div class="card-body bg-secondary"><small class="lh-sm mb-2 d-block"> july, 14 2023 </small>
                <h5 class="card-title text-black">Best Breed of Cow for Milk in India</h5>
                <p class="card-text">From time immemorial, farmers have considered animal husbandry as a second source of income.</p>
                <a href="blog-details.php" class="mt-4 fw-bold">READ MORE</a> </div>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/b3.jpg" class="card-img-top" alt="...">
              <div class="card-body bg-secondary"><small class="lh-sm mb-2 d-block"> july, 14 2023 </small>
                <h5 class="card-title text-black">25 Interesting facts about Cows in India</h5>
                <p class="card-text">Cow has been called mother in Hinduism. In the Puranas, religion is also depicted in the form of a cow.</p>
                <a href="blog-details.php" class="mt-4 fw-bold">READ MORE</a> </div>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/b4.jpg" class="card-img-top" alt="...">
              <div class="card-body bg-secondary"><small class="lh-sm mb-2 d-block"> july, 14 2023 </small>
                <h5 class="card-title text-black">Why is the cow itself a medical science?</h5>
                <p class="card-text">Gomata is a truly divine hospital. In the spine of the cow there is Surya Ketu Nadi which</p>
                <a href="blog-details.php" class="mt-4 	fw-bold">READ MORE</a> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include("includes/footer.php"); ?>