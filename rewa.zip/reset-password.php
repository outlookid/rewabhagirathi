<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Rewa Bhagirathi Sewa - Login</title>
<?php include("includes/header.php"); ?>

<div class="login-page">
  <div class="left"> <img src="assets/images/login-img.jpg" alt=""> </div>
  <div class="right">
	
	  <form action="" class="login-form">
	  <h3 class="mb-4">Set New Password</h3>
		  
		  <div class="form-group mb-3">
		  <label for="" class="col-form-label">Enter New Password</label>
			<input type="text" class="form-control bg-secondary border-2 rounded-0 border-primary">
		  </div>
		  
		   <div class="form-group mb-3">
		  <label for="" class="col-form-label">Re-Enter New Password</label>
			<input type="text" class="form-control bg-secondary border-2 rounded-0 border-primary">
		  </div>
		  
		   
		  
		  <button class="btn btn-primary rounded-0 w-100 mt-4">Reset</button>
		  <div class="d-flex align-items-center justify-content-between my-3" >
		  <span>Remember Now?</span>
			  <a href="login.php">
			  Login here
			  </a>
		  </div>
	  </form>
	  
	</div>
</div>
<?php include("includes/login-footer.php"); ?>
