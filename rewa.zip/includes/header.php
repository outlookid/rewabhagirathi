<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="assets/css/main.css">
<link rel="stylesheet" href="assets/vendors/swiper/swiper-bundle.min.css">
<link rel="stylesheet" href="assets/vendors/fancybox/fancybox.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>
<header class="header">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="d-flex align-items-center">
          <a class="logo" href="index.php"> <img src="assets/images/logo.png" class="img-fluid shadow-sm bg-secondary p-2 rounded-3 rounded-top-0" alt=""> </a>
          <ul class="header-nav">
            <li><a href=""><img src="assets/images/icons/mail.svg" class="me-2" alt=""><span class="d-none d-xl-inline">care@rewabhagirathisewa.com</span></a></li>
            <li><a href=""><img src="assets/images/icons/phone.svg" class="me-2" alt=""><span class="d-none d-xl-inline">994 884 5647</span></a></li>
            <li class="ms-auto d-none d-md-block">
              <a href="donation-form.php" class="btn btn-primary rounded-0">Donate Now</a>
            </li>
            <li class="d-none d-md-inline"><a href="login.php"><img src="assets/images/icons/user-icon.svg" alt=" "></a></li>
            <!--<li class="d-none d-md-inline"><img src="assets/images/icons/search-icon.svg" alt=""></li>-->
            <li class="ms-auto ms-md-1" data-bs-toggle="offcanvas" data-bs-target="#openmenu"><img src="assets/images/icons/nav-icon.svg" alt=""></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</header>
<div class="offcanvas offcanvas-end" tabindex="-1" id="openmenu" >
  <div class="offcanvas-header">
    <h5 class="offcanvas-title">Menu</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <ul class="sidenavmenu">
      <li><a href="login.php">Login</a></li>
	  <li><a href="donor-register.php">Register</a></li>
      <li><a href="index.php">Home</a></li>
      <li><a href="about.php">About us</a></li>
	  <li><a href="gallery.php">Gallery</a></li>
      <li><a href="blogs.php">Blogs</a></li>
      <li><a href="campaign-page.php">Campaigns page</a></li>
    </ul>
  </div>
</div>