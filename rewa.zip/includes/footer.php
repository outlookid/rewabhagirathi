
<section class="bg-primary py-5">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-5">
        <h5 class="text-white fs-1">Subscribe Newslatter</h5>
      </div>
      <div class="col-lg-7">
        <form action="">
          <div class="position-relative">
            <input type="text" placeholder="Enter your mail" class="subscribe-input">
            <button class="btn btn-secondary subsbtn">Subscribe</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
<footer class="bg-secondary py-5">
  <div class="container">
    <div class="row justify-content-center gy-4">
      <div class="col-lg-3 text-center"> <img src="assets/images/logo.png" alt="">
        <ul class="social-share mt-4">
          <li><a href="">
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="18" cy="18" r="17.5" fill="#FEF687" stroke="#C62C31"/>
              <path d="M18.9313 23.9981V18.5341H20.7746L21.0486 16.3948H18.9313V15.0321C18.9313 14.4148 19.1033 13.9921 19.9893 13.9921H21.1119V12.0848C20.5657 12.0262 20.0166 11.998 19.4673 12.0001C17.8379 12.0001 16.7193 12.9948 16.7193 14.8208V16.3908H14.8879V18.5301H16.7233V23.9981H18.9313Z" fill="#C62C31"/>
            </svg>
            </a></li>
          <li><a href="">
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="18" cy="18" r="17.5" fill="#FEF687" stroke="#C62C31"/>
              <path d="M24.5001 12.9734C24.022 13.1797 23.5017 13.3281 22.9657 13.3859C23.5221 13.0554 23.9388 12.5331 24.1376 11.9172C23.6155 12.2278 23.0435 12.4456 22.447 12.5609C22.1977 12.2944 21.8961 12.0821 21.5612 11.9372C21.2262 11.7923 20.865 11.718 20.5001 11.7188C19.0235 11.7188 17.836 12.9156 17.836 14.3844C17.836 14.5906 17.861 14.7969 17.9017 14.9953C15.6907 14.8797 13.7188 13.8234 12.4079 12.2063C12.169 12.6142 12.0439 13.0788 12.0454 13.5516C12.0454 14.4766 12.5157 15.2922 13.2329 15.7719C12.8103 15.7552 12.3975 15.6391 12.0282 15.4328V15.4656C12.0282 16.7609 12.9438 17.8344 14.1642 18.0813C13.935 18.1408 13.6993 18.1712 13.4626 18.1719C13.2892 18.1719 13.1251 18.1547 12.9595 18.1313C13.297 19.1875 14.2798 19.9547 15.4501 19.9797C14.5345 20.6969 13.3876 21.1188 12.1423 21.1188C11.9188 21.1188 11.7126 21.1109 11.4985 21.0859C12.6798 21.8438 14.0813 22.2813 15.5907 22.2813C20.4907 22.2813 23.172 18.2219 23.172 14.6984C23.172 14.5828 23.172 14.4672 23.1642 14.3516C23.6829 13.9719 24.1376 13.5016 24.5001 12.9734Z" fill="#C62C31"/>
            </svg>
            </a></li>
          <li><a href="">
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="18" cy="18" r="17.5" fill="#FEF687" stroke="#C62C31"/>
              <path fill-rule="evenodd" clip-rule="evenodd" d="M16.6233 19.7522V16.0055L20.2253 17.8855L16.6233 19.7522ZM24.5333 15.3568C24.5333 15.3568 24.4033 14.4375 24.0033 14.0328C23.4966 13.5022 22.9279 13.4995 22.6673 13.4682C20.8019 13.3335 18.0026 13.3335 18.0026 13.3335H17.9973C17.9973 13.3335 15.1986 13.3335 13.3326 13.4682C13.0719 13.4995 12.5039 13.5015 11.9966 14.0328C11.5966 14.4375 11.4666 15.3568 11.4666 15.3568C11.4666 15.3568 11.3333 16.4355 11.3333 17.5148V18.5262C11.3333 19.6048 11.4666 20.6842 11.4666 20.6842C11.4666 20.6842 11.5966 21.6028 11.9966 22.0075C12.5033 22.5388 13.1699 22.5215 13.4666 22.5775C14.5333 22.6795 17.9999 22.7108 17.9999 22.7108C17.9999 22.7108 20.8019 22.7068 22.6673 22.5722C22.9279 22.5408 23.4966 22.5388 24.0033 22.0075C24.4033 21.6028 24.5333 20.6842 24.5333 20.6842C24.5333 20.6842 24.6666 19.6048 24.6666 18.5262V17.5148C24.6666 16.4355 24.5333 15.3568 24.5333 15.3568Z" fill="#C62C31"/>
            </svg>
            </a></li>
          <li><a href="">
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="18" cy="18" r="17.5" fill="#FEF687" stroke="#C62C31"/>
              <g clip-path="url(#clip0_298_554)">
                <path d="M13.6321 25.2939V14.9751H10.2024V25.2939H13.6321ZM11.9177 13.5654C13.1137 13.5654 13.8581 12.7731 13.8581 11.7829C13.8359 10.7704 13.1137 10 11.9404 10C10.7672 10 10 10.7704 10 11.7829C10 12.7731 10.7443 13.5654 11.8953 13.5654H11.9176H11.9177ZM15.5305 25.2939H18.9602V19.5314C18.9602 19.223 18.9825 18.9149 19.073 18.6944C19.321 18.0783 19.8853 17.4401 20.8328 17.4401C22.0738 17.4401 22.5703 18.3864 22.5703 19.7735V25.2938H25.9999V19.3771C25.9999 16.2076 24.3078 14.7329 22.0513 14.7329C20.201 14.7329 19.3887 15.7671 18.9374 16.4715H18.9603V14.9749H15.5305C15.5755 15.9432 15.5305 25.2937 15.5305 25.2937L15.5305 25.2939Z" fill="#C62C31"/>
              </g>
              <defs>
                <clipPath id="clip0_298_554">
                  <rect width="16" height="15.2939" fill="white" transform="translate(10 10)"/>
                </clipPath>
              </defs>
            </svg>
            </a></li>
        </ul>
      </div>
      <div class="col-lg-2">
        <h5 class="fw-bold mb-4">About us</h5>
        <ul class="footer-list">
          <li><a href="">Privacy Policy</a></li>
          <li><a href="">Refund Policy</a></li>
          <li><a href="">End User Agreement Policy</a></li>
          <li><a href="">Disclaimer </a></li>
          <li><a href="">Term And Conditions</a></li>
        </ul>
      </div>
      <div class="col-lg-3">
        <h5 class="fw-bold mb-4">Trending post</h5>
        <ul class="footer-list blogli">
          <li> <a href="#"> <span class="date">
            <h4>23</h4>
            Feb</span> <span > Why Cow is Mother of Hindu? Policy <br>
            <img src="assets/images/icons/icomoon-free_eye.svg" alt=""> 1000 views</span> </a> </li>
          <li> <a href="#"> <span class="date">
            <h4>24</h4>
            Feb</span> <span > Save the Cow <br>
            <img src="assets/images/icons/icomoon-free_eye.svg" alt=""> 1000 views</span> </a> </li>
          <li> <a href="#"> <span class="date">
            <h4>25</h4>
            Feb</span> <span> Why is the cow itself a medical science? <br>
            <img src="assets/images/icons/icomoon-free_eye.svg" alt=""> 1000 views</span> </a> </li>
        </ul>
      </div>
      <div class="col-lg-4">
        <h5 class="fw-bold mb-4">Contact Us</h5>
        <ul class="footer-list">
          <li><a href="" class="d-center"><img src="assets/images/icons/home.svg" width="37" alt=""> Sector # 48, 123 Street, miosya road VIC 28</a></li>
          <li><a href="" class="d-center"><img src="assets/images/icons/phone.svg" width="37" alt=""> +00 99 88 5647</a></li>
          <li><a href="" class="d-center"><img src="assets/images/icons/mail.svg" width="37" alt=""> yourmail@gmail.com</a></li>
        </ul>
        <button class="btn btn-outline-primary rounded-0 mt-2">Donate Now</button>
      </div>
    </div>
  </div>
</footer>
<script src="assets/js/jquery-3.6.3.min.js"></script>

<script src="assets/vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script> 
<script src="assets/vendors/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendors/fancybox/fancybox.umd.js"></script>
<script src="assets/js/myscript.js"></script>

</body>
</html>