

<script src="assets/vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script> 
<script src="assets/vendors/swiper/swiper-bundle.min.js"></script> 
<script src="assets/js/myscript.js"></script>

</body>
</html>