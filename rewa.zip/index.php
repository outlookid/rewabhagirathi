<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Rewa Bhagirathi Sewa</title>
<?php include("includes/header.php"); ?>
<section class="main-slider">
  <div class="swiper">
    <div class="swiper-wrapper">
      <div class="swiper-slide"><img src="assets/images/banner1.jpg" alt=""></div>
      <div class="swiper-slide"><img src="assets/images/banner1.jpg" alt=""></div>
      <div class="swiper-slide"><img src="assets/images/banner1.jpg" alt=""></div>
    </div>
  </div>
</section>
<div class="onslidercards">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="placement">
          <h3 class="text-white fs-5 fw-normal mb-4 text-shadow">“Shree Rewa Bhagirathi Desi Gaurakshashala Mahatirth ramgad badwah, Madhya Pradesh”</h3>
          <div class="row ">
            <div class="col-lg-10 order-2 order-lg-1">
              <div class="row g-3">
                <div class="col-lg-3">
                  <div class="card">
                    <div class="card-body"> <a href="" class="slidercard"> <span class="d-flex d-md-block"> <img src="assets/images/fodder.png" class="cardimg" alt="">
                      <h2 class="fs-5 ms-3 ms-md-0">Fodder For Mother Cow</h2>
                      </span>
                      <p>Serve mother cows with fodder, Your luck will be overloader</p>
                      <img src="assets/images/icons/right-arrow.svg" class="slidercardarrow" alt=""></a> </div>
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="card">
                    <div class="card-body"> <a href="" class="slidercard"> <span class="d-flex d-md-block"> <img src="assets/images/events.png" class="cardimg" alt="">
                      <h2 class="fs-5 ms-3 ms-md-0">Events for you</h2>
                      </span>
                      <p>Service to mother cows bring peace, prosperity and happiness in life.</p>
                      <img src="assets/images/icons/right-arrow.svg" class="slidercardarrow" alt=""></a> </div>
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="card">
                    <div class="card-body"> <a href="" class="slidercard"> <span class="d-flex d-md-block"> <img src="assets/images/adoptacow.png" class="cardimg" alt="">
                      <h2 class="fs-5 ms-3 ms-md-0">Adopt a Cow</h2>
                      </span>
                      <p>Those who don't have a name will get fame, Just adopt mother cows and see the game.</p>
                      <img src="assets/images/icons/right-arrow.svg" class="slidercardarrow" alt=""> </a></div>
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="card">
                    <div class="card-body"> <a href="" class="slidercard"> <span class="d-flex d-md-block"> <img src="assets/images/donate-now.png" class="cardimg" alt="">
                      <h2 class="fs-5 ms-3 ms-md-0">Donate Now</h2>
                      </span>
                      <p>Serve mother cows with fodder, Your luck will be overloader</p>
                      <img src="assets/images/icons/right-arrow.svg" class="slidercardarrow" alt=""> </a></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-2 order-1 order-lg-2">
              <div class="slider-buttons">
                <div class="button-prev ms-lg-auto">
                  <svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M3.85445 6.85384C3.808 6.9004 3.75283 6.93735 3.69208 6.96255C3.63134 6.98776 3.56622 7.00073 3.50045 7.00073C3.43468 7.00073 3.36956 6.98776 3.30882 6.96255C3.24807 6.93735 3.19289 6.9004 3.14645 6.85384L0.146449 3.85384C0.0998859 3.80739 0.0629435 3.75222 0.0377369 3.69147C0.0125303 3.63073 -0.000444412 3.56561 -0.000444412 3.49984C-0.000444412 3.43407 0.0125303 3.36895 0.0377369 3.30821C0.0629435 3.24746 0.0998859 3.19228 0.146449 3.14584L3.14645 0.145839C3.24034 0.0519519 3.36767 -0.000792503 3.50045 -0.000792503C3.63322 -0.000792503 3.76056 0.0519519 3.85445 0.145839C3.94834 0.239726 4.00108 0.367063 4.00108 0.499839C4.00108 0.632615 3.94834 0.759952 3.85445 0.853839L1.20745 3.49984L3.85445 6.14584C3.90101 6.19228 3.93796 6.24746 3.96316 6.30821C3.98837 6.36895 4.00134 6.43407 4.00134 6.49984C4.00134 6.56561 3.98837 6.63073 3.96316 6.69147C3.93796 6.75222 3.90101 6.80739 3.85445 6.85384Z" fill="#C62C31"/>
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M12.0004 3.49982C12.0004 3.63243 11.9477 3.7596 11.854 3.85337C11.7602 3.94714 11.633 3.99982 11.5004 3.99982H1.00043C0.867819 3.99982 0.740642 3.94714 0.646873 3.85337C0.553105 3.7596 0.500427 3.63243 0.500427 3.49982C0.500427 3.36721 0.553105 3.24003 0.646873 3.14626C0.740642 3.05249 0.867819 2.99982 1.00043 2.99982H11.5004C11.633 2.99982 11.7602 3.05249 11.854 3.14626C11.9477 3.24003 12.0004 3.36721 12.0004 3.49982Z" fill="#C62C31"/>
                  </svg>
                </div>
                <div class="button-next">
                  <svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M8.14555 6.85384C8.192 6.9004 8.24717 6.93735 8.30792 6.96255C8.36866 6.98776 8.43378 7.00073 8.49955 7.00073C8.56532 7.00073 8.63044 6.98776 8.69118 6.96255C8.75193 6.93735 8.80711 6.9004 8.85355 6.85384L11.8536 3.85384C11.9001 3.80739 11.9371 3.75222 11.9623 3.69147C11.9875 3.63073 12.0004 3.56561 12.0004 3.49984C12.0004 3.43407 11.9875 3.36895 11.9623 3.30821C11.9371 3.24746 11.9001 3.19228 11.8536 3.14584L8.85355 0.145839C8.75966 0.0519519 8.63233 -0.000792503 8.49955 -0.000792503C8.36678 -0.000792503 8.23944 0.0519519 8.14555 0.145839C8.05166 0.239726 7.99892 0.367063 7.99892 0.499839C7.99892 0.632615 8.05166 0.759952 8.14555 0.853839L10.7926 3.49984L8.14555 6.14584C8.09899 6.19228 8.06204 6.24746 8.03684 6.30821C8.01163 6.36895 7.99866 6.43407 7.99866 6.49984C7.99866 6.56561 8.01163 6.63073 8.03684 6.69147C8.06204 6.75222 8.09899 6.80739 8.14555 6.85384Z" fill="#C62C31"/>
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M-0.000427246 3.49982C-0.000427246 3.63243 0.0522513 3.7596 0.146019 3.85337C0.239788 3.94714 0.366965 3.99982 0.499573 3.99982H10.9996C11.1322 3.99982 11.2594 3.94714 11.3531 3.85337C11.4469 3.7596 11.4996 3.63243 11.4996 3.49982C11.4996 3.36721 11.4469 3.24003 11.3531 3.14626C11.2594 3.05249 11.1322 2.99982 10.9996 2.99982H0.499573C0.366965 2.99982 0.239788 3.05249 0.146019 3.14626C0.0522513 3.24003 -0.000427246 3.36721 -0.000427246 3.49982Z" fill="#C62C31"/>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="container-fluid bg-secondary ourcampaigns">
  <div class="row">
    <div class="col-lg-12">
      <div class="container">
        <div class="row gy-4">
          <div class="col-lg-12">
            <div class="d-flex mb-4 align-items-center justify-content-between">
              <h2 class="fw-bold">Our Campaigns</h2>
              <button class="btn btn-primary rounded-0">See All Campaigns</button>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="card border-primary border-2 rounded-4 overflow-hidden">
			<img src="assets/images/cam1.jpg" class="card-img-top" alt="...">
              <div class="card-body  p-4">
                <h5 class="card-title text-black">Gaugrass</h5>
                <p class="card-text">Once a cow grows old and stop giving milk, their owner disowns them because they are of no</p>
                <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                  <div class="progress-bar" style="width: 25%">25%</div>
                </div>
                <div class="d-flex align-items-center justify-content-between small mt-2"> <span>10 Days To Go </span> <span>Goal: ₹50.000</span> </div>
                <div class="text-center"> <a href="#" class="btn btn-primary mt-4 rounded-0">Donate Now</a> </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/cam1.jpg" class="card-img-top" alt="...">
              <div class="card-body  p-4">
                <h5 class="card-title text-black">Godaan</h5>
                <p class="card-text">Once a cow grows old and stop giving milk, their owner disowns them because they are of no</p>
                <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                  <div class="progress-bar" style="width: 25%">25%</div>
                </div>
                <div class="d-flex align-items-center justify-content-between small mt-2"> <span>10 Days To Go </span> <span>Goal: ₹50.000</span> </div>
                <div class="text-center"> <a href="#" class="btn btn-primary mt-4 rounded-0">Donate Now</a> </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/cam1.jpg" class="card-img-top" alt="...">
              <div class="card-body  p-4">
                <h5 class="card-title text-black">Shraad</h5>
                <p class="card-text">Once a cow grows old and stop giving milk, their owner disowns them because they are of no</p>
                <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                  <div class="progress-bar" style="width: 25%">25%</div>
                </div>
                <div class="d-flex align-items-center justify-content-between small mt-2"> <span>10 Days To Go </span> <span>Goal: ₹50.000</span> </div>
                <div class="text-center"> <a href="#" class="btn btn-primary mt-4 rounded-0">Donate Now</a> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="container mt-5 pb-5">
  <div class="row gy-4">
    <div class="col-lg-12">
      <div class="d-flex mb-4 align-items-center justify-content-between">
        <h2 class="fw-bold">Latest Updates</h2>
        <button class="btn btn-primary rounded-0">See All Updates</button>
      </div>
    </div>
    <div class="col-xl-12">
      <div class="swiper mySwiper">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <div class="card updates-card">
              <div class="card-body">
                <h3 class="fs-5">Send a Charitable</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="card updates-card">
              <div class="card-body">
                <h3 class="fs-5">Send a Charitable</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="card updates-card">
              <div class="card-body">
                <h3 class="fs-5">Send a Charitable</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="card updates-card">
              <div class="card-body">
                <h3 class="fs-5">Send a Charitable</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="card updates-card">
              <div class="card-body">
                <h3 class="fs-5">Send a Charitable</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
        </div>
        <div class="swiper-pagination"></div>
      </div>
    </div>
    <div class="col-lg-12">
      <div class="text-center mt-4">
        <h2 class="fw-bold">Sewa</h2>
        <p>This Organization is Committed Towards Cow by Doing the Following Activities</p>
      </div>
    </div>
    <div class="col-lg-12">
      <div class="row gy-4">
        <div class="col-lg-3">
          <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/sewa1.jpg" class="card-img-top" alt="...">
            <div class="card-body bg-secondary">
              <h5 class="card-title text-black">Cow protection</h5>
              <p class="card-text">In the Vedic tradition, cows are worshipped as mothers. Just as a child feeds on the breast milk of the mother, human society takes milk from the cow. The cows are an integral part of the temples</p>
              <a href="#" class="mt-4 fw-bold">READ MORE</a> </div>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/sewa2.jpg" class="card-img-top" alt="...">
            <div class="card-body bg-secondary">
              <h5 class="card-title text-black">Self-reliant</h5>
              <p class="card-text">In the Vedic tradition, cows are worshipped as mothers. Just as a child feeds on the breast milk of the mother, human society takes milk from the cow. The cows are an integral part of the temples</p>
              <a href="#" class="mt-4 fw-bold">READ MORE</a> </div>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/sewa3.jpg" class="card-img-top" alt="...">
            <div class="card-body bg-secondary">
              <h5 class="card-title text-black">Sheltering &amp; Feeding</h5>
              <p class="card-text">In the Vedic tradition, cows are worshipped as mothers. Just as a child feeds on the breast milk of the mother, human society takes milk from the cow. The cows are an integral part of the temples</p>
              <a href="#" class="mt-4 fw-bold">READ MORE</a> </div>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/sewa4.jpg" class="card-img-top" alt="...">
            <div class="card-body bg-secondary">
              <h5 class="card-title text-black">Spreading knowledge</h5>
              <p class="card-text">In the Vedic tradition, cows are worshipped as mothers. Just as a child feeds on the breast milk of the mother, human society takes milk from the cow. The cows are an integral part of the temples</p>
              <a href="#" class="mt-4 	fw-bold">READ MORE</a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<section class="blog-section">
  <div class="container">
    <div class="row gy-4">
      <div class="col-lg-12">
        <div class="text-center">
          <h2 class="fw-bold">Latest Blog</h2>
          <p>That they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail</p>
        </div>
      </div>
      <div class="col-lg-12">
        <div class="row gy-4">
          <div class="col-lg-3">
            <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/b1.jpg" class="card-img-top" alt="...">
              <div class="card-body bg-secondary"> <small class="lh-sm mb-2 d-block"> july, 14 2023 </small>
                <h5 class="card-title text-black">Why Cow is Mother of Hindu?</h5>
                <p class="card-text">In our Hindu culture, cow is not only considered as an animal but also as a lorem
                  <deity class=""></deity>
                </p>
                <a href="blog-details.php" class="mt-4 fw-bold">READ MORE</a> </div>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/b2.jpg" class="card-img-top" alt="...">
              <div class="card-body bg-secondary"><small class="lh-sm mb-2 d-block"> july, 14 2023 </small>
                <h5 class="card-title text-black">Best Breed of Cow for Milk in India</h5>
                <p class="card-text">From time immemorial, farmers have considered animal husbandry as a second source of income.</p>
                <a href="blog-details.php" class="mt-4 fw-bold">READ MORE</a> </div>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/b3.jpg" class="card-img-top" alt="...">
              <div class="card-body bg-secondary"><small class="lh-sm mb-2 d-block"> july, 14 2023 </small>
                <h5 class="card-title text-black">25 Interesting facts about Cows in India</h5>
                <p class="card-text">Cow has been called mother in Hinduism. In the Puranas, religion is also depicted in the form of a cow.</p>
                <a href="blog-details.php" class="mt-4 fw-bold">READ MORE</a> </div>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="card border-primary border-2 rounded-4 overflow-hidden"> <img src="assets/images/b4.jpg" class="card-img-top" alt="...">
              <div class="card-body bg-secondary"><small class="lh-sm mb-2 d-block"> july, 14 2023 </small>
                <h5 class="card-title text-black">Why is the cow itself a medical science?</h5>
                <p class="card-text">Gomata is a truly divine hospital. In the spine of the cow there is Surya Ketu Nadi which</p>
                <a href="blog-details.php" class="mt-4 fw-bold">READ MORE</a> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="container mt-5">
  <div class="row">
    <div class="col-lg-12">
      <div class="d-flex mb-4 align-items-center flex-column justify-content-center">
        <h2 class="fw-bold">Testimonials</h2>
      </div>
    </div>
    <div class="col-xl-12">
      <div class="swiper mySwiper">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <div class="card test-card bg-secondary border-2 border-primary">
              <div class="card-body text-center"> <img src="assets/images/yogi.png" class="test-image" alt="">
                <h3 class="fs-5 mb-0 text-primary">Shri Yogi Adityanath</h3>
                <small class="text-uppercase">CM, Uttar Pradesh</small> <img src="assets/images/stars.svg" class="starwidth" alt="">
                <p>I was overwhelmed to see the continuous service of thousands of destitute cows in Shri Krishnayan Gaushala. This gaushala can be ideal in the field of Gauseva.</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="card test-card bg-secondary border-2 border-primary">
              <div class="card-body text-center"> <img src="assets/images/yogi.png" class="test-image" alt="">
                <h3 class="fs-5 mb-0 text-primary">Shri Yogi Adityanath</h3>
                <small class="text-uppercase">CM, Uttar Pradesh</small> <img src="assets/images/stars.svg" class="starwidth" alt="">
                <p>I was overwhelmed to see the continuous service of thousands of destitute cows in Shri Krishnayan Gaushala. This gaushala can be ideal in the field of Gauseva.</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="card test-card bg-secondary border-2 border-primary">
              <div class="card-body text-center"> <img src="assets/images/yogi.png" class="test-image" alt="">
                <h3 class="fs-5 mb-0 text-primary">Shri Yogi Adityanath</h3>
                <small class="text-uppercase">CM, Uttar Pradesh</small> <img src="assets/images/stars.svg" class="starwidth" alt="">
                <p>I was overwhelmed to see the continuous service of thousands of destitute cows in Shri Krishnayan Gaushala. This gaushala can be ideal in the field of Gauseva.</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="card test-card bg-secondary border-2 border-primary">
              <div class="card-body text-center"> <img src="assets/images/yogi.png" class="test-image" alt="">
                <h3 class="fs-5 mb-0 text-primary">Shri Yogi Adityanath</h3>
                <small class="text-uppercase">CM, Uttar Pradesh</small> <img src="assets/images/stars.svg" class="starwidth" alt="">
                <p>I was overwhelmed to see the continuous service of thousands of destitute cows in Shri Krishnayan Gaushala. This gaushala can be ideal in the field of Gauseva.</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <div class="swiper-slide">
            <div class="card test-card bg-secondary border-2 border-primary">
              <div class="card-body text-center"> <img src="assets/images/yogi.png" class="test-image" alt="">
                <h3 class="fs-5 mb-0 text-primary">Shri Yogi Adityanath</h3>
                <small class="text-uppercase">CM, Uttar Pradesh</small> <img src="assets/images/stars.svg" class="starwidth" alt="">
                <p>I was overwhelmed to see the continuous service of thousands of destitute cows in Shri Krishnayan Gaushala. This gaushala can be ideal in the field of Gauseva.</p>
                <a href="" class="fw-bold text-uppercase">READ MORE</a> </div>
            </div>
          </div>
          <!----> 
          
        </div>
        <div class="swiper-pagination"></div>
      </div>
    </div>
  </div>
</section>

<?php include("includes/footer.php"); ?>